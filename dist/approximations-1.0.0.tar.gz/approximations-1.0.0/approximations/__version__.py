"""Current version of package approximations"""
__version__ = "1.0.0"